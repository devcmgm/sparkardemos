//==============================================================================
// The following example demonstrates how to send a JSON request to an online
// API.
//
// Project setup:
// - Whitelist the jsonplaceholder.typicode.com domain in Capabilities
//==============================================================================

// Load in the required modules
const Diagnostics = require('Diagnostics');
const Networking = require('Networking');

//==============================================================================
// Create the request
//==============================================================================

// Store the URL we're sending the request to
const url = 'http://50.63.164.2:7777/alexa/t1.py';

// Create a request object
const request = {

  // The HTTP Method of the request
  // (https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods)
  method: 'POST',

  // The HTTP Headers of the request
  // (https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers)
  headers: {'Content-type': 'application/json; charset=UTF-8'},

  // The data to send, in string format
  body: JSON.stringify({title: 'Networking Module'})

};

//==============================================================================
// Send the request and log the results
//==============================================================================

// Send the request to the url
Networking.fetch(url, request).then(function(result) {

  // Check the status of the result
  // (https://developer.mozilla.org/en-US/docs/Web/HTTP/Status)
  if ((result.status >= 200) && (result.status < 300)) {

    // If the request was successful, chain the JSON forward
    return result.json();

  }

  // If the request was not successful, throw an error
  throw new Error('HTTP status code - ' + result.status);

}).then(function(json) {

  // Log the JSON obtained by the successful request
  Diagnostics.log('Successfully sent - ' + json.title);

}).catch(function(error) {

  // Log any errors that may have happened with the request
  Diagnostics.log('Error - ' + error.message);

});
// How to log values to the console

